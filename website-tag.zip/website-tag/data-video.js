
console.log('Test');
const videoAnuncio = document.getElementById('video-anuncio');

videoAnuncio.addEventListener('timeupdate', () => {
  const tiempoActual = videoAnuncio.currentTime;
  const duracion = videoAnuncio.duration;
  const porcentajeAvance = (tiempoActual / duracion) * 100;

  console.log('Tiempo actual:', tiempoActual);
  console.log('Duración del video:', duracion);
  console.log('Porcentaje de avance:', porcentajeAvance);
});
